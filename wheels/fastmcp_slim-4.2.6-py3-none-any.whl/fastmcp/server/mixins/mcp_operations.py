"""MCP protocol handler setup and wire-format handlers for FastMCP Server."""

from __future__ import annotations

import inspect
from typing import TYPE_CHECKING, Any, cast

import mcp_types
from mcp.server.context import ServerRequestContext
from mcp.shared.exceptions import MCPError
from mcp_types import (
    INVALID_PARAMS,
    CallToolRequestParams,
    CompleteRequestParams,
    EmptyResult,
    GetPromptRequestParams,
    PaginatedRequestParams,
    ReadResourceRequestParams,
    SetLevelRequestParams,
)
from mcp_types.version import MODERN_PROTOCOL_VERSIONS
from pydantic import BaseModel

from fastmcp.exceptions import (
    DisabledError,
    FastMCPError,
    NotFoundError,
    to_mcp_error,
)
from fastmcp.prompts.base import InputRequiredPromptResult
from fastmcp.resources.base import InputRequiredResourceResult
from fastmcp.server.completions import CompletionValues, normalize_completion
from fastmcp.server.dependencies import (
    _serving_client_tool_call,
    bind_request_context,
    extract_version_spec,
)
from fastmcp.tools.base import (
    InputRequiredToolResult,
    RawStructuredToolResult,
    ToolResult,
)
from fastmcp.utilities.async_utils import (
    call_sync_fn_in_threadpool,
    is_coroutine_function,
)
from fastmcp.utilities.json_schema import is_object_schema
from fastmcp.utilities.logging import get_logger
from fastmcp.utilities.pagination import paginate_request
from fastmcp.utilities.versions import VersionSpec, dedupe_with_versions

if TYPE_CHECKING:
    from fastmcp.prompts.base import Prompt
    from fastmcp.resources.template import ResourceTemplate
    from fastmcp.server.server import FastMCP

logger = get_logger(__name__)


def _normalize_call_tool_result(
    result: Any,
) -> mcp_types.CallToolResult:
    """Normalize a tool's ``to_mcp_result()`` output into a ``CallToolResult``.

    ``ToolResult.to_mcp_result()`` returns one of three shapes for backward
    compatibility: a ``CallToolResult`` (error/meta case), a bare
    ``list[ContentBlock]`` (unstructured), or a ``(content, structured)`` tuple.
    The SDK v2 runner requires a ``BaseModel`` result, so wrap the shorthand
    forms here (the SDK's old ``call_tool`` decorator used to do this).
    """
    if isinstance(result, mcp_types.CallToolResult):
        return result
    if isinstance(result, tuple):
        content, structured = result
        return mcp_types.CallToolResult(content=content, structured_content=structured)
    return mcp_types.CallToolResult(content=result)


def _version_from_ctx(ctx: ServerRequestContext) -> VersionSpec | None:
    """Extract the FastMCP component version from the request's lifted _meta."""
    from fastmcp.server.dependencies import _lift_meta

    version_str = extract_version_spec(_lift_meta(ctx))
    return VersionSpec(eq=version_str) if version_str else None


class MCPOperationsMixin:
    """Mixin providing MCP protocol handler setup and wire-format handlers.

    Handlers are registered via ``add_request_handler(method, params_type,
    handler)`` on the low-level SDK server. Each adapter takes
    ``(ctx: ServerRequestContext, params)`` and returns the bare SDK result
    model (no ``ServerResult`` wrapping — the SDK v2 runner serializes the
    result itself).
    """

    def _setup_handlers(self: FastMCP) -> None:
        """Register core MCP protocol handlers with the low-level SDK server."""
        s = self._mcp_server
        s.add_request_handler("tools/list", PaginatedRequestParams, self._on_list_tools)
        s.add_request_handler(
            "resources/list", PaginatedRequestParams, self._on_list_resources
        )
        s.add_request_handler(
            "resources/templates/list",
            PaginatedRequestParams,
            self._on_list_resource_templates,
        )
        s.add_request_handler(
            "prompts/list", PaginatedRequestParams, self._on_list_prompts
        )
        s.add_request_handler("tools/call", CallToolRequestParams, self._on_call_tool)
        s.add_request_handler(
            "resources/read", ReadResourceRequestParams, self._on_read_resource
        )
        s.add_request_handler(
            "prompts/get", GetPromptRequestParams, self._on_get_prompt
        )
        s.add_request_handler(
            "logging/setLevel", SetLevelRequestParams, self._on_set_logging_level
        )

    async def _on_list_tools(
        self: FastMCP,
        ctx: ServerRequestContext,
        params: PaginatedRequestParams | None,
    ) -> mcp_types.ListToolsResult:
        """List all available tools. Supports pagination via params.cursor."""
        with bind_request_context(ctx):
            logger.debug(f"[{self.name}] Handler called: list_tools")

            tools = dedupe_with_versions(
                list(await self.list_tools()), lambda t: t.name
            )
            sdk_tools = []
            for tool in tools:
                output_schema = tool.output_schema
                if (
                    ctx.protocol_version not in MODERN_PROTOCOL_VERSIONS
                    and output_schema is not None
                ):
                    if (
                        is_object_schema(output_schema)
                        and output_schema.get("type") != "object"
                    ):
                        # Implicit and nullable object schemas are valid JSON
                        # Schema, but legacy MCP requires a literal object type
                        # at the root. A null result is sent without structured
                        # content, which legacy clients already accept.
                        output_schema = {**output_schema, "type": "object"}
                    elif not is_object_schema(output_schema):
                        output_schema = {
                            "type": "object",
                            "properties": {"result": output_schema},
                            "required": ["result"],
                            "x-fastmcp-wrap-result": True,
                            # Local references inside the original schema still
                            # resolve from the document root after wrapping.
                            **(
                                {"$defs": output_schema["$defs"]}
                                if "$defs" in output_schema
                                else {}
                            ),
                            **(
                                {"definitions": output_schema["definitions"]}
                                if "definitions" in output_schema
                                else {}
                            ),
                        }
                sdk_tools.append(
                    tool.to_mcp_tool(name=tool.name, outputSchema=output_schema)
                )
            # Refresh the Mcp-Param schema cache (served to the SDK's
            # `get_tool_input_schema` hook, mcp>=2.3) from the full visible
            # set, pre-pagination: these are the authoritative wire schemas,
            # including proxied and mounted tools. Merged in place with
            # `update` (never `clear`) — the dict is shared with
            # _SchemaCacheLocalProvider and single server-wide, so an
            # auth-scoped listing of one client must not evict the schemas
            # another (differently authorized) client validated against. The
            # cache may therefore hold a superset of any one client's listing;
            # a stale entry can only appear for tools removed remotely between
            # listings, and a miss stays fail-open.
            self._wire_input_schemas.update(
                {
                    sdk_tool.name: sdk_tool.input_schema
                    for sdk_tool in sdk_tools
                    if sdk_tool.input_schema is not None
                }
            )
            cursor = params.cursor if params else None
            page, next_cursor = paginate_request(
                sdk_tools, cursor, self._list_page_size
            )
            return mcp_types.ListToolsResult(tools=page, next_cursor=next_cursor)

    async def _on_list_resources(
        self: FastMCP,
        ctx: ServerRequestContext,
        params: PaginatedRequestParams | None,
    ) -> mcp_types.ListResourcesResult:
        """List all available resources. Supports pagination via params.cursor."""
        with bind_request_context(ctx):
            logger.debug(f"[{self.name}] Handler called: list_resources")

            resources = dedupe_with_versions(
                list(await self.list_resources()), lambda r: str(r.uri)
            )
            sdk_resources = [
                resource.to_mcp_resource(uri=str(resource.uri))
                for resource in resources
            ]
            cursor = params.cursor if params else None
            page, next_cursor = paginate_request(
                sdk_resources, cursor, self._list_page_size
            )
            return mcp_types.ListResourcesResult(
                resources=page, next_cursor=next_cursor
            )

    async def _on_list_resource_templates(
        self: FastMCP,
        ctx: ServerRequestContext,
        params: PaginatedRequestParams | None,
    ) -> mcp_types.ListResourceTemplatesResult:
        """List all available resource templates. Supports pagination."""
        with bind_request_context(ctx):
            logger.debug(f"[{self.name}] Handler called: list_resource_templates")

            templates = dedupe_with_versions(
                list(await self.list_resource_templates()), lambda t: t.uri_template
            )
            sdk_templates = [
                template.to_mcp_template(uri_template=template.uri_template)
                for template in templates
            ]
            cursor = params.cursor if params else None
            page, next_cursor = paginate_request(
                sdk_templates, cursor, self._list_page_size
            )
            return mcp_types.ListResourceTemplatesResult(
                resource_templates=page, next_cursor=next_cursor
            )

    async def _on_list_prompts(
        self: FastMCP,
        ctx: ServerRequestContext,
        params: PaginatedRequestParams | None,
    ) -> mcp_types.ListPromptsResult:
        """List all available prompts. Supports pagination via params.cursor."""
        with bind_request_context(ctx):
            logger.debug(f"[{self.name}] Handler called: list_prompts")

            prompts = dedupe_with_versions(
                list(await self.list_prompts()), lambda p: p.name
            )
            sdk_prompts = [prompt.to_mcp_prompt(name=prompt.name) for prompt in prompts]
            cursor = params.cursor if params else None
            page, next_cursor = paginate_request(
                sdk_prompts, cursor, self._list_page_size
            )
            return mcp_types.ListPromptsResult(prompts=page, next_cursor=next_cursor)

    async def _on_call_tool(
        self: FastMCP,
        ctx: ServerRequestContext,
        params: CallToolRequestParams,
    ) -> mcp_types.CallToolResult | mcp_types.InputRequiredResult | BaseModel:
        """Handle MCP 'tools/call' requests.

        A guard tool (SEP-2322 multi-round-trip) requests client input by
        returning an ``InputRequiredResult`` from its body; the run machinery
        wraps that in an ``InputRequiredToolResult`` (a ``ToolResult``
        subclass), which flows back through the middleware chain as an ordinary
        result. Here we unwrap it and hand the raw ``InputRequiredResult`` to
        the runner so it reaches the wire as ``resultType: "input_required"``
        (the request-state boundary seals its ``requestState`` on egress). This
        result shape only exists at 2026-07-28; on an earlier connection the
        runner cannot serialize it, so we reject with a clear era error rather
        than let it fail as a generic "invalid result".
        """
        with bind_request_context(ctx):
            key = params.name
            arguments = params.arguments or {}
            logger.debug(
                f"[{self.name}] Handler called: call_tool %s with %s", key, arguments
            )

            version = _version_from_ctx(ctx)

            try:
                with _serving_client_tool_call():
                    result = await self.call_tool(key, arguments, version=version)
            except (DisabledError, NotFoundError):
                # Unknown/disabled tool: return an error result (matching the
                # v1 SDK's call_tool behavior) so the client surfaces a
                # ToolError rather than a raw protocol error.
                return mcp_types.CallToolResult(
                    content=[
                        mcp_types.TextContent(
                            type="text", text=f"Unknown tool: {key!r}"
                        )
                    ],
                    is_error=True,
                )
            except FastMCPError as e:
                # Tool-visible errors (ToolError, ValidationError, ...) must be
                # RETURNED as an error result, never raised — the SDK v2 runner
                # turns a raise into a -32603 wire error. Masking already
                # happened inside call_tool.
                return mcp_types.CallToolResult(
                    content=[mcp_types.TextContent(type="text", text=str(e))],
                    is_error=True,
                )

            if not isinstance(result, ToolResult):
                # An extension's tools/call interceptor produced a non-ToolResult
                # wire result — the tasks extension's CreateTaskResult when it ran
                # the call as a task. Core does not interpret extension result
                # shapes; hand it straight to the runner, which serializes it for
                # the negotiated protocol version.
                return result

            if isinstance(result, InputRequiredToolResult):
                # A guard tool requested client input (SEP-2322). The
                # multi-round-trip result type only exists at 2026-07-28; on an
                # earlier connection the runner cannot serialize it, so name the
                # era problem instead of failing as a generic "invalid result".
                if ctx.protocol_version not in MODERN_PROTOCOL_VERSIONS:
                    raise MCPError(
                        code=INVALID_PARAMS,
                        message=(
                            f"Tool {key!r} returned an InputRequiredResult to request "
                            "client input, but the multi-round-trip result type "
                            "(SEP-2322) only exists at MCP 2026-07-28; this connection "
                            f"negotiated {ctx.protocol_version!r}. Use ctx.elicit() for "
                            "server-initiated input on handshake-era connections."
                        ),
                    )
                return result.input_required
            # Tool._run marks results declared by a non-object output schema
            # as raw; legacy clients receive them under the advertised
            # `result` wrapper.
            if ctx.protocol_version not in MODERN_PROTOCOL_VERSIONS and (
                isinstance(result, RawStructuredToolResult)
                or (
                    result.structured_content is not None
                    and not isinstance(result.structured_content, dict)
                )
            ):
                fastmcp_meta = result.meta.get("fastmcp") if result.meta else None
                already_wrapped = (
                    isinstance(fastmcp_meta, dict)
                    and fastmcp_meta.get("wrap_result") is True
                )
                if not already_wrapped:
                    meta = dict(result.meta or {})
                    meta["fastmcp"] = {
                        **(fastmcp_meta if isinstance(fastmcp_meta, dict) else {}),
                        "wrap_result": True,
                    }
                    result = ToolResult(
                        content=result.content,
                        structured_content={"result": result.structured_content},
                        meta=meta,
                        is_error=result.is_error,
                    )
            return _normalize_call_tool_result(result.to_mcp_result())

    async def _on_read_resource(
        self: FastMCP,
        ctx: ServerRequestContext,
        params: ReadResourceRequestParams,
    ) -> mcp_types.ReadResourceResult | mcp_types.InputRequiredResult:
        """Handle MCP 'resources/read' requests."""
        with bind_request_context(ctx):
            uri = params.uri
            logger.debug(f"[{self.name}] Handler called: read_resource %s", uri)

            version = _version_from_ctx(ctx)

            try:
                result = await self.read_resource(str(uri), version=version)
            except (DisabledError, NotFoundError) as e:
                # SEP-2164: echo the requested URI in `data` so a client that
                # pipelined several reads can tell which one is missing.
                raise MCPError(
                    code=INVALID_PARAMS,
                    message=f"Resource not found: {str(uri)!r}",
                    data={"uri": str(uri)},
                ) from e
            except FastMCPError as e:
                # Resource-visible errors (ResourceError, ValidationError, ...)
                # must reach the wire as an MCPError. Resources have no
                # error-result shape the way tools do, so the equivalent of
                # _on_call_tool's error result is a translated MCPError: at
                # 2026-07-28 the runner only preserves MCPError/ValidationError
                # messages and masks anything else as "Internal server error",
                # which would hide a legitimate client-input error. Masking
                # already happened inside read_resource.
                raise to_mcp_error(e) from e

            if isinstance(result, InputRequiredResourceResult):
                # The resource requested client input (SEP-2322). As with tools
                # and prompts, the multi-round-trip result type only exists at
                # 2026-07-28, so name the era problem on an older connection
                # rather than failing as a generic "invalid result".
                if ctx.protocol_version not in MODERN_PROTOCOL_VERSIONS:
                    raise MCPError(
                        code=INVALID_PARAMS,
                        message=(
                            f"Resource {str(uri)!r} returned an InputRequiredResult "
                            "to request client input, but the multi-round-trip "
                            "result type (SEP-2322) only exists at MCP 2026-07-28; "
                            f"this connection negotiated {ctx.protocol_version!r}."
                        ),
                    )
                return result.input_required

            return result.to_mcp_result(uri)

    async def _on_get_prompt(
        self: FastMCP,
        ctx: ServerRequestContext,
        params: GetPromptRequestParams,
    ) -> mcp_types.GetPromptResult | mcp_types.InputRequiredResult:
        """Handle MCP 'prompts/get' requests."""
        with bind_request_context(ctx):
            name = params.name
            arguments = params.arguments
            logger.debug(
                f"[{self.name}] Handler called: get_prompt %s with %s",
                name,
                arguments,
            )

            version = _version_from_ctx(ctx)

            try:
                result = await self.render_prompt(name, arguments, version=version)
            except (DisabledError, NotFoundError) as e:
                raise to_mcp_error(NotFoundError(f"Unknown prompt: {name!r}")) from e
            except FastMCPError as e:
                # Prompt-visible errors (PromptError, ValidationError, ...) must
                # reach the wire as an MCPError for the same reason as
                # resources: at 2026-07-28 anything that is not an
                # MCPError/ValidationError is masked as "Internal server error".
                # Masking already happened inside render_prompt.
                raise to_mcp_error(e) from e

            if isinstance(result, InputRequiredPromptResult):
                # The prompt requested client input (SEP-2322). As with tools,
                # the multi-round-trip result type only exists at 2026-07-28, so
                # name the era problem on an older connection rather than
                # failing as a generic "invalid result".
                if ctx.protocol_version not in MODERN_PROTOCOL_VERSIONS:
                    raise MCPError(
                        code=INVALID_PARAMS,
                        message=(
                            f"Prompt {name!r} returned an InputRequiredResult to "
                            "request client input, but the multi-round-trip result "
                            "type (SEP-2322) only exists at MCP 2026-07-28; this "
                            f"connection negotiated {ctx.protocol_version!r}."
                        ),
                    )
                return result.input_required

            return result.to_mcp_prompt_result()

    async def _on_set_logging_level(
        self: FastMCP,
        ctx: ServerRequestContext,
        params: SetLevelRequestParams,
    ) -> mcp_types.EmptyResult:
        """Handle MCP 'logging/setLevel' requests.

        Stores the requested minimum log level so that subsequent log messages
        below this level are suppressed. v2 sessions are per-request, so the
        level lives on the client's connection, where mounted servers handling
        the same connection also see it.
        """
        from fastmcp.server.context import _CONNECTION_LOG_LEVEL_KEY

        with bind_request_context(ctx) as rc:
            logger.debug(
                f"[{self.name}] Handler called: set_logging_level %s", params.level
            )
            rc.session._connection.state[_CONNECTION_LOG_LEVEL_KEY] = params.level
            return EmptyResult()

    async def _on_complete(
        self: FastMCP,
        ctx: ServerRequestContext,
        params: CompleteRequestParams,
    ) -> mcp_types.CompleteResult:
        """Handle MCP 'completion/complete' requests.

        Routes to the server's registered completion handler (set via
        ``@mcp.completion``). The handler switches on the reference and argument
        and returns candidate values. A handler that does not recognize the
        reference/argument returns ``None`` or an empty sequence, which becomes
        an empty completion rather than an error — an unknown reference is not a
        protocol failure. A reference the caller cannot see (disabled, hidden by
        a visibility transform, or denied by its own `auth`) gets the same empty
        completion, so completion never discloses what listing hides. This
        handler is registered on the low-level server only once a completion
        handler exists, so the completions capability is declared exactly when
        the server can answer.
        """
        empty = mcp_types.CompleteResult(completion=mcp_types.Completion(values=[]))
        with bind_request_context(ctx):
            logger.debug(f"[{self.name}] Handler called: complete %s", params.ref)
            handler = self._completion_handler
            if handler is None:
                return empty

            ref = params.ref
            key = ref.name if isinstance(ref, mcp_types.PromptReference) else ref.uri
            if await self._completion_target(ref.type, key) is None:
                return empty

            if is_coroutine_function(handler):
                raw = handler(params.ref, params.argument, params.context)
            else:
                # A sync handler may perform blocking work (a database lookup,
                # say); run it in a threadpool so it does not stall the event
                # loop, matching how sync tools/prompts/resources are invoked.
                raw = await call_sync_fn_in_threadpool(
                    handler, params.ref, params.argument, params.context
                )
            result = await raw if inspect.isawaitable(raw) else raw
            completion = normalize_completion(cast(CompletionValues, result))
            return mcp_types.CompleteResult(completion=completion)

    async def _completion_target(
        self: FastMCP, ref_type: str, key: str
    ) -> Prompt | ResourceTemplate | None:
        """The visible prompt or template a completion reference names, if any.

        Resolves without middleware, so a completion stays one request to rate
        limits and caches (see test_completions.py).
        """
        if ref_type == "ref/prompt":
            return await self.get_prompt(key)
        # A template's own identifier does not always match it as a URI
        # (query-only templates such as `data://search{?q}`), so look for the
        # template itself before treating the reference as a concrete URI.
        # Several versions can share the identifier; pick the one clients list.
        matches = [
            template
            for template in await self.list_resource_templates(run_middleware=False)
            if template.uri_template == key
        ]
        if matches:
            return dedupe_with_versions(matches, lambda t: t.uri_template)[0]
        return await self.get_resource_template(key)

    def _register_completion_handler(self: FastMCP) -> None:
        """Register the low-level ``completion/complete`` handler.

        Called when a completion handler is set (via
        ``add_completion_handler``) so the SDK derives the completions
        capability from the handler's presence. Registration is idempotent —
        re-registering replaces the handler.
        """
        self._mcp_server.add_request_handler(
            "completion/complete",
            CompleteRequestParams,
            self._on_complete,
        )
