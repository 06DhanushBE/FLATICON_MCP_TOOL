"""Request director using openapi-core for stateless HTTP request building."""

import io
import json as _json
import re
from email.message import Message
from typing import Any, ClassVar
from urllib.parse import quote, unquote

import httpx2
from jsonschema import Draft202012Validator
from jsonschema.protocols import Validator
from jsonschema_path import SchemaPath

from fastmcp.utilities.logging import get_logger

from .models import HTTPRoute, ParameterInfo
from .schemas import _combine_schemas_and_map_params, _ref_is_mergeable_object

logger = get_logger(__name__)

_MAX_PATH_DECODINGS = 32
_PATH_TEMPLATE_PARAM = re.compile(r"\{([^{}]+)\}")
# RFC 6265 cookie-octets left as-is in a cookie value (`%` is not, so the
# encoding stays unambiguous). Everything else is percent-encoded.
_COOKIE_SAFE = "!#$&'()*+-./:<=>?@[]^_`{|}~"


def _query_scalar_to_str(value: Any) -> str:
    """Convert a scalar to its query-string representation.

    Booleans are lowercased to match JSON/OpenAPI conventions (true/false)
    rather than Python's str(True) → "True".
    """
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _uses_default_multipart_encoding(encoding: dict[str, Any]) -> bool:
    """Explicit defaults serialize like omitted encoding; overrides stay unchanged."""
    defaults = {
        "style": "form",
        "explode": True,
        "contentType": "text/plain",
        "allowReserved": False,
        "headers": {},
    }
    return all(
        key in defaults and value == defaults[key] for key, value in encoding.items()
    )


def _is_json_media_type(content_type: str | None) -> bool:
    """Return whether a media type denotes JSON, ignoring parameters."""
    if not content_type:
        return False
    media_type = content_type.split(";")[0].strip().lower()
    return media_type == "application/json" or media_type.endswith("+json")


def _resolve_schema_ref(
    schema: Any,
    definitions: dict[str, Any],
    active_refs: frozenset[str] = frozenset(),
) -> tuple[dict[str, Any], frozenset[str]]:
    """Resolve a local `$ref`, tracking references active on this traversal path.

    Returns the resolved schema (empty when the chain cycles or cannot be
    resolved) plus the extended active-reference set. Callers recurse through
    composition keywords with that set so mutually recursive component graphs
    terminate instead of overflowing the stack.
    """
    while isinstance(schema, dict) and isinstance(schema.get("$ref"), str):
        ref = schema["$ref"]
        if ref in active_refs:
            return {}, active_refs
        active_refs = active_refs | {ref}
        target = definitions.get(ref.rsplit("/", 1)[-1])
        if not isinstance(target, dict):
            return {}, active_refs
        schema = target
    return (schema if isinstance(schema, dict) else {}), active_refs


def _schema_type_includes(schema: dict[str, Any], type_name: str) -> bool:
    """Return whether `type` declares the given type, including type lists."""
    schema_type = schema.get("type")
    if schema_type == type_name:
        return True
    return isinstance(schema_type, list) and type_name in schema_type


def _schema_is_object(
    schema: Any,
    definitions: dict[str, Any],
    active_refs: frozenset[str] = frozenset(),
) -> bool:
    """Return whether a schema (or any composition branch) describes an object."""
    schema, active_refs = _resolve_schema_ref(schema, definitions, active_refs)
    if not schema:
        return False
    if (
        _schema_type_includes(schema, "object")
        or "properties" in schema
        or "additionalProperties" in schema
    ):
        return True
    for keyword in ("allOf", "anyOf", "oneOf"):
        members = schema.get(keyword)
        if isinstance(members, list) and any(
            _schema_is_object(member, definitions, active_refs) for member in members
        ):
            return True
    return False


def _schema_is_array_of_objects(
    schema: Any,
    definitions: dict[str, Any],
    value: list[Any],
    active_refs: frozenset[str] = frozenset(),
) -> bool:
    """Return whether a schema describes an object array matching `value`.

    Composition alternatives are chosen against the runtime items: a `oneOf`
    or `anyOf` that offers both `array<object>` and `array<string>` keeps a
    string list on the string branch, so it is not JSON-encoded for an unused
    object branch.
    """
    schema, active_refs = _resolve_schema_ref(schema, definitions, active_refs)
    if not schema:
        return False
    if _schema_type_includes(schema, "array"):
        item_schemas: list[Any] = []
        items = schema.get("items")
        if isinstance(items, list):
            item_schemas.extend(items)
        elif items is not None:
            item_schemas.append(items)
        prefix_items = schema.get("prefixItems")
        if isinstance(prefix_items, list):
            item_schemas.extend(prefix_items)
        if any(
            _schema_is_object(item, definitions, active_refs) for item in item_schemas
        ):
            # Empty arrays carry no runtime type information; preserve the
            # object-array behavior there.
            return not value or any(isinstance(item, dict) for item in value)
        return False
    for keyword in ("allOf", "anyOf", "oneOf"):
        members = schema.get(keyword)
        if isinstance(members, list) and any(
            _schema_is_array_of_objects(member, definitions, value, active_refs)
            for member in members
        ):
            return True
    return False


def _form_property_schemas(
    body_schema: dict[str, Any], definitions: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """Collect a form body's property schemas, merging `allOf` members.

    Returns the declared properties plus the `additionalProperties` schema
    (if any) that applies to names not declared in `properties`.
    """
    properties: dict[str, Any] = {}
    additional_properties: dict[str, Any] | None = None

    def collect(schema: Any, active_refs: frozenset[str] = frozenset()) -> None:
        nonlocal additional_properties
        schema, active_refs = _resolve_schema_ref(schema, definitions, active_refs)
        if not schema:
            return
        if isinstance(schema.get("properties"), dict):
            properties.update(schema["properties"])
        if additional_properties is None:
            extra = schema.get("additionalProperties")
            if isinstance(extra, dict):
                additional_properties = extra
        members = schema.get("allOf")
        if isinstance(members, list):
            for member in members:
                collect(member, active_refs)

    collect(body_schema)
    return properties, additional_properties


def _build_form_urlencoded_data(
    body: dict[str, Any],
    body_schema: dict[str, Any],
    encoding: dict[str, dict[str, Any]],
    definitions: dict[str, Any],
) -> dict[str, Any]:
    """Serialize structured urlencoded fields as JSON per the OAS Encoding Object.

    Object properties default to `contentType: application/json`, so they must
    be JSON-encoded rather than passed to httpx for Python `repr` stringification.
    An explicit encoding `contentType` overrides that default. Scalars and
    arrays of scalars keep httpx's form encoding (arrays repeat the key).
    """
    properties, additional_properties = _form_property_schemas(body_schema, definitions)
    data: dict[str, Any] = {}
    for name, value in body.items():
        content_type = encoding.get(name, {}).get("contentType")
        if content_type is not None:
            json_encode = _is_json_media_type(content_type)
        else:
            prop_schema = properties.get(name, additional_properties or {})
            json_encode = (
                (
                    isinstance(value, dict)
                    and _schema_is_object(prop_schema, definitions)
                )
                or (
                    isinstance(value, list)
                    and _schema_is_array_of_objects(prop_schema, definitions, value)
                )
                or (value is None and _schema_is_object(prop_schema, definitions))
            )
        data[name] = _json.dumps(value, allow_nan=False) if json_encode else value
    return data


def _required_json_object_without_properties(route: HTTPRoute) -> bool:
    """Return whether an omitted required JSON object body should be sent empty.

    Flattened object properties are optional tool arguments. Leaving all of
    them out is still an empty JSON object. Optional bodies stay absent.
    """
    request_body = route.request_body
    if (
        request_body is None
        or not request_body.required
        or not request_body.content_schema
    ):
        return False
    content_type = next(iter(request_body.content_schema))
    media_type = content_type.split(";")[0].strip().lower()
    if media_type != "application/json" and not media_type.endswith("+json"):
        return False
    body_schema = request_body.content_schema[content_type]
    return (
        isinstance(body_schema, dict)
        and bool(body_schema.get("properties"))
        and _ref_is_mergeable_object(body_schema, route.request_schemas)
    )


def _prepare_parameter_map(
    route: HTTPRoute,
) -> tuple[HTTPRoute, dict[str, dict[str, str]]]:
    """Return the route's parameter map, building it if the route lacks one.

    Routes from the OpenAPI parser carry a precomputed map. Routes constructed
    directly may declare parameters or a request body without one; those get
    the map the parser would have built, computed on a copy so the caller's
    route is left unchanged. Those routes also accept `<name>__<location>`
    for each declared parameter, naming the parameter at that location. An
    empty map for a route with no parameters and no request body is already
    complete.
    """
    if route.parameter_map or not (route.parameters or route.request_body):
        return route, route.parameter_map

    request_body = (
        route.request_body.model_copy(deep=True) if route.request_body else None
    )
    prepared = route.model_copy(update={"request_body": request_body})
    _, parameter_map = _combine_schemas_and_map_params(prepared, convert_refs=False)
    for param in route.parameters:
        parameter_map.setdefault(
            f"{param.name}__{param.location}",
            {"location": param.location, "openapi_name": param.name},
        )
    return prepared, parameter_map


def _missing_path_arguments(
    route: HTTPRoute,
    parameter_map: dict[str, dict[str, str]],
    arguments: dict[str, Any],
) -> list[str]:
    """Name the arguments for declared path parameters that have no value.

    A path parameter is satisfied when any argument mapped to it is present and
    not None; `build` drops None path values, so null counts as missing. Only
    parameters that appear in the path template and that the caller can supply
    through the parameter map are checked. A template placeholder with no
    declared parameter is a spec fault, which `build` still reports.
    """
    template_names = set(_PATH_TEMPLATE_PARAM.findall(route.path))
    aliases: dict[str, list[str]] = {}
    for arg_name, mapping in parameter_map.items():
        if mapping["location"] == "path":
            aliases.setdefault(mapping["openapi_name"], []).append(arg_name)
    missing = []
    for param in route.parameters:
        if param.location != "path" or param.name not in template_names:
            continue
        names = aliases.get(param.name)
        if names and all(arguments.get(name) is None for name in names):
            missing.append(names[0])
    return missing


class RequestDirector:
    """Builds httpx2.Request objects from HTTPRoute and arguments using openapi-core."""

    def __init__(self, spec: SchemaPath):
        """Initialize with a parsed SchemaPath object."""
        self._spec = spec

    def build(
        self,
        route: HTTPRoute,
        flat_args: dict[str, Any],
        base_url: str = "http://localhost",
    ) -> httpx2.Request:
        """
        Constructs a final httpx2.Request object, handling all OpenAPI serialization.

        Args:
            route: HTTPRoute containing OpenAPI operation details
            flat_args: Flattened arguments from LLM (may include suffixed parameters)
            base_url: Base URL for the request

        Returns:
            httpx2.Request: Properly formatted HTTP request
        """
        logger.debug(
            f"Building request for {route.method} {route.path} with args: {flat_args}"
        )

        # Step 1: Un-flatten arguments into path, query, body, etc. using parameter map
        path_params, query_params, header_params, cookie_params, body = (
            self._unflatten_arguments(route, flat_args)
        )

        logger.debug(
            f"Unflattened - path: {path_params}, query: {query_params}, headers: {header_params}, body: {body}"
        )

        # Step 2: Serialize query parameters according to OpenAPI style/explode
        query_params = self._serialize_query_params(route, query_params)

        # Step 3: Build base URL with path parameters
        url = self._build_url(
            route.path,
            path_params,
            base_url,
            path_explode={
                p.name: bool(p.explode)
                for p in route.parameters
                if p.location == "path"
            },
            path_style={
                p.name: p.style
                for p in route.parameters
                if p.location == "path" and p.style
            },
        )

        # Step 4: Prepare request data
        method: str = route.method.upper()
        params = query_params if query_params else None
        # Header parameters always use the OpenAPI "simple" style; values must
        # be strings or httpx rejects the request outright.
        header_lookup: dict[str, ParameterInfo] = {
            p.name: p for p in route.parameters if p.location == "header"
        }
        headers = (
            {
                k: self._simple_param_to_str(
                    v,
                    explode=bool(header_lookup[k].explode)
                    if k in header_lookup
                    else False,
                )
                for k, v in header_params.items()
            }
            if header_params
            else None
        )
        json_body: dict[str, Any] | list[Any] | str | int | float | bool | None = None
        content: str | bytes | None = None

        # Step 5: Determine the declared content type from the OpenAPI spec.
        # Use the raw value for outgoing Content-Type headers (preserves
        # parameters like charset), but normalize for dispatch matching.
        raw_content_type: str | None = None
        declared_content_type: str | None = None
        if route.request_body and route.request_body.content_schema:
            raw_content_type = next(iter(route.request_body.content_schema))
            declared_content_type = raw_content_type.split(";")[0].strip().lower()

        # Cookie parameters always use the OpenAPI "form" style. Build the
        # Cookie header directly so exploded arrays and objects can repeat
        # names, which httpx's cookies= mapping cannot express.
        cookie_pairs = self._serialize_cookie_params(route, cookie_params)
        if cookie_pairs:
            headers = dict(headers) if headers else {}
            cookie_value = "; ".join(f"{name}={value}" for name, value in cookie_pairs)
            existing_cookie = next(
                (name for name in headers if name.lower() == "cookie"), None
            )
            if existing_cookie is None:
                headers["Cookie"] = cookie_value
            else:
                existing = str(headers[existing_cookie])
                headers[existing_cookie] = (
                    f"{existing}; {cookie_value}" if existing else cookie_value
                )

        # Step 6: Handle request body — dispatch on declared content type.
        # httpx body kwargs (json, content, data, files) are mutually exclusive
        # but all accept None, so we set exactly one and pass all to Request().
        files: list[tuple[str, Any]] | None = None
        data: dict[str, Any] | None = None
        if body is not None:
            if declared_content_type == "multipart/form-data" and isinstance(
                body, dict
            ):
                # Wrap plain values as (None, stringified) tuples so httpx
                # treats them as form fields. Scalars must be stringified
                # because httpx rejects non-string/bytes values in files=.
                # Use _query_scalar_to_str for booleans (true/false, not True/False).
                files = []
                encoding = (
                    route.request_body.encoding.get(raw_content_type, {})
                    if route.request_body and raw_content_type is not None
                    else {}
                )
                for k, v in body.items():
                    if (
                        isinstance(v, list)
                        and v
                        and all(isinstance(item, str) for item in v)
                        and _uses_default_multipart_encoding(encoding.get(k, {}))
                    ):
                        files.extend((k, (None, item)) for item in v)
                    elif isinstance(v, tuple):
                        files.append((k, v))
                    elif isinstance(v, bytes | io.IOBase):
                        # bytes and file-like objects are passed directly so
                        # httpx can transmit them as binary parts without
                        # stringifying to their Python repr.
                        files.append((k, (None, v)))
                    else:
                        files.append((k, (None, _query_scalar_to_str(v))))
            elif (
                declared_content_type == "application/x-www-form-urlencoded"
                and isinstance(body, dict)
            ):
                request_body = route.request_body
                body_schema = (
                    request_body.content_schema.get(raw_content_type, {})
                    if request_body and raw_content_type is not None
                    else {}
                )
                definitions = dict(route.request_schemas)
                if isinstance(body_schema.get("$defs"), dict):
                    definitions.update(body_schema["$defs"])
                encoding = (
                    request_body.encoding.get(raw_content_type, {})
                    if request_body and raw_content_type is not None
                    else {}
                )
                data = _build_form_urlencoded_data(
                    body, body_schema, encoding, definitions
                )
            elif (
                isinstance(body, dict | list)
                or declared_content_type == "application/json"
                or (
                    declared_content_type is not None
                    and declared_content_type.endswith("+json")
                )
            ):
                if (
                    raw_content_type is not None
                    and declared_content_type is not None
                    and raw_content_type != "application/json"
                    and "json" in declared_content_type
                ):
                    # JSON media types with parameters or custom subtypes need
                    # an explicit Content-Type header since httpx's json=
                    # always sets bare application/json.
                    content = _json.dumps(body, allow_nan=False).encode("utf-8")
                    headers = dict(headers) if headers else {}
                    headers["Content-Type"] = raw_content_type
                else:
                    json_body = body
            else:
                # httpx rejects numbers and booleans as raw content
                content = (
                    _query_scalar_to_str(body)
                    if isinstance(body, bool | int | float)
                    else body
                )
                if raw_content_type is not None:
                    headers = dict(headers) if headers else {}
                    headers["Content-Type"] = raw_content_type
                    if isinstance(content, str):
                        media_type = Message()
                        media_type["Content-Type"] = raw_content_type
                        content = content.encode(
                            media_type.get_content_charset() or "utf-8"
                        )

        # Step 7: Create httpx2.Request
        return httpx2.Request(
            method=method,
            url=url,
            params=params,
            headers=headers,
            json=json_body,
            content=content,
            data=data,
            files=files,
        )

    def _unflatten_arguments(
        self, route: HTTPRoute, flat_args: dict[str, Any]
    ) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any], Any]:
        """
        Maps flat arguments back to their OpenAPI locations using the parameter map.

        The parameter map is the only source of argument locations. Arguments
        that are not in the map are dropped, so a route that declares no
        parameters and no request body sends none.

        Args:
            route: HTTPRoute with parameter_map containing location mappings
            flat_args: Flat arguments from LLM call

        Returns:
            Tuple of (path_params, query_params, header_params, cookie_params, body)
        """
        path_params = {}
        query_params = {}
        header_params = {}
        cookie_params = {}
        body_props = {}

        route, parameter_map = _prepare_parameter_map(route)
        null_validator: Validator | None = None
        null_properties: dict[str, Any] = {}

        for arg_name, value in flat_args.items():
            if arg_name not in parameter_map:
                logger.warning(
                    f"Argument '{arg_name}' not found in parameter map for {route.operation_id}"
                )
                continue

            mapping = parameter_map[arg_name]
            location = mapping["location"]
            openapi_name = mapping["openapi_name"]

            if value is None:
                # Only JSON body properties have a null representation. Consult
                # the normalized input schema, including its reference definitions,
                # rather than interpreting raw OpenAPI nullability a second time.
                if location != "body" or not route.request_body:
                    continue
                content_type = next(iter(route.request_body.content_schema), "")
                media_type = content_type.split(";")[0].strip().lower()
                if media_type != "application/json" and not media_type.endswith(
                    "+json"
                ):
                    continue
                if null_validator is None:
                    schema = route.flat_param_schema
                    if not schema:
                        schema, _ = _combine_schemas_and_map_params(route)
                    null_validator = Draft202012Validator(schema)
                    null_properties = schema.get("properties", {})
                property_schema = null_properties.get(arg_name, False)
                if not null_validator.evolve(schema=property_schema).is_valid(None):
                    continue

            if location == "path":
                path_params[openapi_name] = value
            elif location == "query":
                query_params[openapi_name] = value
            elif location == "header":
                header_params[openapi_name] = value
            elif location == "cookie":
                cookie_params[openapi_name] = value
            elif location == "body":
                body_props[openapi_name] = value
            else:
                logger.warning(
                    f"Unknown parameter location '{location}' for {arg_name}"
                )

        # Handle body construction
        body = None
        if body_props:
            # If we have body properties, construct the body object
            if (
                route.request_body
                and route.request_body.content_schema
                and len(route.request_body.content_schema) > 0
            ):
                content_type = next(iter(route.request_body.content_schema))
                body_schema = route.request_body.content_schema[content_type]

                # Only named properties are flattened into individual arguments.
                if (
                    isinstance(body_schema, dict)
                    and body_schema.get("properties")
                    and _ref_is_mergeable_object(body_schema, route.request_schemas)
                ):
                    body = body_props
                elif len(body_props) == 1:
                    # Free-form objects, arrays, and primitives use a single
                    # argument containing the entire body.
                    body = next(iter(body_props.values()))
                else:
                    body = body_props
            else:
                body = body_props
        elif _required_json_object_without_properties(route):
            body = {}

        return path_params, query_params, header_params, cookie_params, body

    # Delimiter per OpenAPI style when explode=false
    _STYLE_DELIMITERS: ClassVar[dict[str, str]] = {
        "form": ",",
        "spaceDelimited": " ",
        "pipeDelimited": "|",
    }

    def _serialize_cookie_params(
        self, route: HTTPRoute, cookie_params: dict[str, Any]
    ) -> list[tuple[str, str]]:
        """Serialize cookie parameter values per the OpenAPI form style.

        Cookie parameters always use the form style, where `explode` defaults
        to true. Exploded arrays repeat the parameter name and exploded
        objects use each property name, while the non-exploded forms join with
        commas. Empty collections are omitted.
        """
        if not cookie_params:
            return []

        param_lookup: dict[str, ParameterInfo] = {
            p.name: p for p in route.parameters if p.location == "cookie"
        }

        pairs: list[tuple[str, str]] = []
        for name, value in cookie_params.items():
            param_info = param_lookup.get(name)
            explode = (
                param_info.explode
                if param_info is not None and param_info.explode is not None
                else True
            )
            if isinstance(value, dict):
                if not value:
                    continue
                if explode:
                    for key, item in value.items():
                        pairs.append(
                            (
                                quote(
                                    _query_scalar_to_str(key),
                                    safe=_COOKIE_SAFE.replace("=", ""),
                                ),
                                self._cookie_scalar_to_str(name, item),
                            )
                        )
                else:
                    parts: list[str] = []
                    for key, item in value.items():
                        parts.append(self._cookie_joined_item(name, key))
                        parts.append(self._cookie_joined_item(name, item))
                    pairs.append((name, ",".join(parts)))
            elif isinstance(value, list | tuple):
                if not value:
                    continue
                if explode:
                    pairs.extend(
                        (name, self._cookie_scalar_to_str(name, item)) for item in value
                    )
                else:
                    pairs.append(
                        (
                            name,
                            ",".join(
                                self._cookie_joined_item(name, item) for item in value
                            ),
                        )
                    )
            else:
                pairs.append((name, self._cookie_scalar_to_str(name, value)))
        return pairs

    @staticmethod
    def _cookie_scalar_to_str(param_name: str, value: Any) -> str:
        """Serialize a cookie scalar, percent-encoding it for the Cookie header.

        RFC 6265 cookie values exclude `;`, `,`, `"`, `\\`, whitespace, controls
        and non-ASCII, and OpenAPI's form style percent-encodes them. Without
        this, a `;` in a tool argument would split the header and add cookies
        the operation never declared.
        """
        if isinstance(value, dict | list | tuple):
            raise ValueError(
                f"Cookie parameter '{param_name}' contains a nested "
                f"{type(value).__name__}; cookie form serialization supports "
                "only scalar values"
            )
        return quote(_query_scalar_to_str(value), safe=_COOKIE_SAFE)

    @classmethod
    def _cookie_joined_item(cls, param_name: str, value: Any) -> str:
        """Encode a non-exploded cookie item; `,` and `=` also separate items."""
        return (
            cls._cookie_scalar_to_str(param_name, value)
            .replace(",", "%2C")
            .replace("=", "%3D")
        )

    def _serialize_query_params(
        self,
        route: HTTPRoute,
        query_params: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Serialize query parameter values according to their OpenAPI style/explode settings.

        By default (style=form, explode=true), list values are passed through as-is
        so httpx repeats the key (e.g. values=a&values=b). For pipeDelimited and
        spaceDelimited arrays, omitted explode defaults to false. Object values
        retain the existing default of true. When explode=false,
        list values are joined with the style-appropriate delimiter:
          - form (default): comma  (values=a,b)
          - pipeDelimited:  pipe   (values=a|b)
          - spaceDelimited: space  (values=a%20b)
        """
        if not query_params:
            return query_params

        # Build a lookup from openapi_name -> ParameterInfo for query params
        param_lookup: dict[str, ParameterInfo] = {
            p.name: p for p in route.parameters if p.location == "query"
        }

        serialized: dict[str, Any] = {}

        def add(name: str, value: Any) -> None:
            # Exploded form objects emit bare property names, which can match
            # another parameter's name; keep every value so the key repeats.
            if name not in serialized:
                serialized[name] = value
                return
            existing = serialized[name]
            serialized[name] = [
                *(existing if isinstance(existing, list) else [existing]),
                *(value if isinstance(value, list) else [value]),
            ]

        for key, value in query_params.items():
            param_info = param_lookup.get(key)
            if param_info is not None:
                style = param_info.style or "form"
                explode = param_info.explode if param_info.explode is not None else True
                if (
                    param_info.explode is None
                    and isinstance(value, list)
                    and style in {"pipeDelimited", "spaceDelimited"}
                ):
                    explode = False
                if isinstance(value, dict):
                    if not value:
                        continue
                    if explode:
                        for k, v in value.items():
                            # deepObject keeps the parent parameter name;
                            # form style emits each property as a bare key.
                            property_name = _query_scalar_to_str(k)
                            if param_info.style == "deepObject":
                                property_name = f"{key}[{property_name}]"
                            add(property_name, _query_scalar_to_str(v))
                    else:
                        delimiter = self._STYLE_DELIMITERS.get(style, ",")
                        # form,explode=false on objects: key,value pairs
                        # e.g. {"R": 100, "G": 200} → "R,100,G,200"
                        parts: list[str] = []
                        for k, v in value.items():
                            parts.append(_query_scalar_to_str(k))
                            parts.append(_query_scalar_to_str(v))
                        add(key, delimiter.join(parts))
                    continue
                if not explode:
                    delimiter = self._STYLE_DELIMITERS.get(style, ",")
                    if isinstance(value, list):
                        if not value:
                            continue
                        add(key, delimiter.join(_query_scalar_to_str(v) for v in value))
                        continue
            add(key, value)
        return serialized

    @staticmethod
    def _simple_param_to_str(value: Any, explode: bool = False) -> str:
        """Serialize a value per the OpenAPI "simple" style (path and header parameters).

        Arrays join with commas either way; explode only changes object
        serialization from "k,v" pairs to "k=v" pairs.
        """
        if isinstance(value, dict):
            parts: list[str] = []
            for k, v in value.items():
                if explode:
                    parts.append(f"{_query_scalar_to_str(k)}={_query_scalar_to_str(v)}")
                else:
                    parts.append(_query_scalar_to_str(k))
                    parts.append(_query_scalar_to_str(v))
            return ",".join(parts)
        if isinstance(value, list | tuple):
            # The simple style defines primitive items only; flatten a nested
            # list one level instead of leaking its Python repr.
            parts = []
            for v in value:
                if isinstance(v, list | tuple):
                    parts.extend(_query_scalar_to_str(i) for i in v)
                else:
                    parts.append(_query_scalar_to_str(v))
            return ",".join(parts)
        return _query_scalar_to_str(value)

    def _encode_path_scalar(self, param_name: str, value: Any) -> str:
        """Encode one scalar path item, rejecting dot segments at any encoding layer."""
        serialized = _query_scalar_to_str(value)
        decoded = serialized
        for _ in range(_MAX_PATH_DECODINGS):
            if any(
                part in {".", ".."} for part in decoded.replace("\\", "/").split("/")
            ):
                raise ValueError(
                    f"Path parameter '{param_name}' cannot contain dot segments"
                )
            expanded = unquote(decoded)
            if expanded == decoded:
                break
            decoded = expanded
        else:
            raise ValueError(
                f"Path parameter '{param_name}' has too many encoding layers"
            )
        # quote() leaves "." unencoded; replace it so a dot segment can never
        # reconstitute after a server decodes the path.
        return quote(serialized, safe="").replace(".", "%2E")

    def _simple_param_to_path_segment(
        self, param_name: str, value: Any, explode: bool = False
    ) -> str:
        """Serialize a path parameter per the OpenAPI "simple" style, encoding each
        item separately so the style separators stay literal on the wire."""
        if isinstance(value, dict):
            parts = []
            for k, v in value.items():
                ek = self._encode_path_scalar(param_name, k)
                ev = self._encode_path_scalar(param_name, v)
                parts.append(f"{ek}={ev}" if explode else f"{ek},{ev}")
            return ",".join(parts)
        if isinstance(value, list | tuple):
            # Mirror the header side: flatten a nested list one level instead
            # of leaking its Python repr onto the wire.
            parts = []
            for v in value:
                if isinstance(v, list | tuple):
                    parts.extend(self._encode_path_scalar(param_name, i) for i in v)
                else:
                    parts.append(self._encode_path_scalar(param_name, v))
            return ",".join(parts)
        return self._encode_path_scalar(param_name, value)

    @staticmethod
    def _restyle_path_segment(
        param_name: str, value: Any, segment: str, style: str, explode: bool
    ) -> str:
        """Turn a "simple" path segment into the OpenAPI "label" or "matrix" form.

        Every item in `segment` is already percent-encoded, so each literal ","
        is a delimiter and exploding just swaps it for the style's separator.
        """
        if style == "label":
            segment = "." + (segment.replace(",", ".") if explode else segment)
            if not segment.strip("."):
                raise ValueError(
                    f"Path parameter '{param_name}' cannot serialize to a dot segment"
                )
            return segment
        # An exploded matrix object names each property instead of the parameter.
        if explode and isinstance(value, dict):
            return ";" + segment.replace(",", ";")
        prefix = f";{quote(param_name, safe='')}="
        if explode and isinstance(value, list | tuple):
            return prefix + segment.replace(",", prefix)
        return prefix + segment

    def _build_url(
        self,
        path_template: str,
        path_params: dict[str, Any],
        base_url: str,
        path_explode: dict[str, bool] | None = None,
        path_style: dict[str, str] | None = None,
    ) -> str:
        """
        Build URL by substituting path parameters in the template.

        Args:
            path_template: OpenAPI path template (e.g., "/users/{id}")
            path_params: Path parameter values
            base_url: Base URL to prepend
            path_explode: Per-parameter explode flags from the route's parameter
                definitions; absent names default to the non-exploded form
            path_style: Per-parameter styles from the route's parameter
                definitions; absent names default to "simple"

        Returns:
            Complete URL with path parameters substituted

        Raises:
            ValueError: If the template has a parameter with no value
        """
        missing = [
            name
            for name in dict.fromkeys(_PATH_TEMPLATE_PARAM.findall(path_template))
            if name not in path_params
        ]
        if missing:
            names = ", ".join(repr(name) for name in missing)
            raise ValueError(f"Missing required path parameters: {{{names}}}")

        # Path parameters default to the OpenAPI "simple" style, so values are
        # serialized before substitution (e.g. true/false for booleans, "a,b"
        # for arrays) instead of leaking Python reprs into the URL. Each item
        # is encoded separately and the style separators (",", "=") stay
        # literal, so ids=["a", "b"] and ids=["a,b"] stay distinct on the
        # wire; dot-segment validation runs per serialized item.
        path_explode = path_explode or {}
        path_style = path_style or {}
        url_path = path_template
        for param_name, param_value in path_params.items():
            placeholder = f"{{{param_name}}}"
            if placeholder in url_path:
                explode = path_explode.get(param_name, False)
                safe_value = self._simple_param_to_path_segment(
                    param_name, param_value, explode
                )
                style = path_style.get(param_name)
                if style == "label" or style == "matrix":
                    safe_value = self._restyle_path_segment(
                        param_name, param_value, safe_value, style, explode
                    )
                url_path = url_path.replace(placeholder, safe_value)

        # Combine with base URL. Plain concatenation: urljoin would read a
        # leading "name:" segment (e.g. "/job-1:cancel") as a URL scheme.
        return f"{base_url.rstrip('/')}/{url_path.lstrip('/')}"


# Export public symbols
__all__ = ["RequestDirector"]
